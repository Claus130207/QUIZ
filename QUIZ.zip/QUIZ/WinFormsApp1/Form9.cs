﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }
        public static int nr = Form8.nr;
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
                MessageBox.Show("Răspuns corect", "Corect");
                ++nr;
                Form10 f10 = new Form10();
                f10.Show();
                Visible = false;
            }
            else
            {
                MessageBox.Show("Răspuns greșit, Coreea de N", "Greșit");
                Form10 f10 = new Form10();
                f10.Show();
                Visible = false;
            }
        }

        private void laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("7 din 25", "Întrebări");
        }

        private void ceTrebuieSăFacToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Alege o variantă și apasă pe butonul (Răspunde)");
        }

        private void ieșireToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
