﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form26 : Form
    {
        public Form26()
        {
            InitializeComponent();
        }
        public static int nr = Form25.nr;
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                MessageBox.Show("Răspun corect", "Corect");
                ++nr;
                Form27 f27 = new Form27();
                f27.Show();
                Visible = false;
            }
            else
            {
                MessageBox.Show("Răspuns greșit, Luxemburg", "Greșit");
                Form27 f27 = new Form27();
                f27.Show();
                Visible = false;
            }
        }

        private void laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("24 din 25", "Întrebări");
        }

        private void ceTrebuieSăFacToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Alege o variabilă și apasă pe butonul (Răspunde)");
        }

        private void ieșireToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
