﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }
        public static int nr = Form10.nr;
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton4.Checked == true)
            {
                MessageBox.Show("Răspuns corect", "Corect");
                ++nr;
                Form12 f12 = new Form12();
                f12.Show();
                Visible = false;
            }
            else
            {
                MessageBox.Show("Răspuns greșit, Cuba", "Greșit");
                Form12 f12 = new Form12();
                f12.Show();
                Visible = false;
            }
        }

        private void laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("9 din 25", "Întrebări");
        }

        private void ceTrebuieSăFacToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Alege o variantă și apasă pe butonul (Răspunde)");
        }

        private void ieșireToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
