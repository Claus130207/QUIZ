﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form24 : Form
    {
        public Form24()
        {
            InitializeComponent();
        }
        public static int nr = Form23.nr;
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
                MessageBox.Show("Răspun corect", "Corect");
                ++nr;
                Form25 f25 = new Form25();
                f25.Show();
                Visible = false;
            }
            else
            {
                MessageBox.Show("Răspuns greșit, Italia", "Greșit");
                Form25 f25 = new Form25();
                f25.Show();
                Visible = false;
            }
        }

        private void laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("22 din 25", "Întrebări");
        }

        private void ceTrebuieSăFacToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Alege o variabilă și apasă pe butonul (Răspunde)");
        }

        private void ieșireToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
