﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        public static int nr = Form5.nr;
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton4.Checked == true)
            {
                MessageBox.Show("Răspuns corect", "Corect");
                ++nr;
                Form7 f7 = new Form7();
                f7.Show();
                Visible = false;
            }
            else
            {
                MessageBox.Show("Răspuns greșit, Cehia", "Greșit");
                Form7 f7 = new Form7();
                f7.Show();
                Visible = false;
            }
        }

        private void laCăteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("4 din 25", "Întrebări");
        }

        private void ceTrebuieSăFacToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Alege o variantă și apasă pe butonul (Răspunde)");
        }

        private void ieșireToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
