﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form16 : Form
    {
        public Form16()
        {
            InitializeComponent();
        }
        public static int nr = Form15.nr;
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton4.Checked == true)
            {
                MessageBox.Show("Răspuns corect", "Corect");
                ++nr;
                Form17 f17 = new Form17();
                f17.Show();
                Visible = false;
            }
            else
            {
                MessageBox.Show("Răspuns greșit, Filipine", "Greșit");
                Form17 f17 = new Form17();
                f17.Show();
                Visible = false;
            }
        }

        private void laCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("14 din 25", "Întrebări");
        }

        private void ceTrebuieSăFacToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Alege o variantă și apasă pe butonul (Răspunde)");
        }

        private void ieșireToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
