﻿namespace WinFormsApp1
{
    partial class Form21
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            menuToolStripMenuItem = new ToolStripMenuItem();
            laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem = new ToolStripMenuItem();
            ceTrebuieSăFacToolStripMenuItem = new ToolStripMenuItem();
            ieșireToolStripMenuItem = new ToolStripMenuItem();
            groupBox1 = new GroupBox();
            button1 = new Button();
            radioButton4 = new RadioButton();
            radioButton3 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            pictureBox1 = new PictureBox();
            menuStrip1.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { menuToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            menuToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem, ceTrebuieSăFacToolStripMenuItem, ieșireToolStripMenuItem });
            menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            menuToolStripMenuItem.Size = new Size(60, 24);
            menuToolStripMenuItem.Text = "Menu";
            // 
            // laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem
            // 
            laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem.Name = "laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem";
            laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem.Size = new Size(355, 26);
            laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem.Text = "La câte întrebări am răspuns până acum";
            laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem.Click += laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem_Click;
            // 
            // ceTrebuieSăFacToolStripMenuItem
            // 
            ceTrebuieSăFacToolStripMenuItem.Name = "ceTrebuieSăFacToolStripMenuItem";
            ceTrebuieSăFacToolStripMenuItem.Size = new Size(355, 26);
            ceTrebuieSăFacToolStripMenuItem.Text = "Ce trebuie să fac";
            ceTrebuieSăFacToolStripMenuItem.Click += ceTrebuieSăFacToolStripMenuItem_Click;
            // 
            // ieșireToolStripMenuItem
            // 
            ieșireToolStripMenuItem.Name = "ieșireToolStripMenuItem";
            ieșireToolStripMenuItem.Size = new Size(355, 26);
            ieșireToolStripMenuItem.Text = "Ieșire";
            ieșireToolStripMenuItem.Click += ieșireToolStripMenuItem_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(radioButton4);
            groupBox1.Controls.Add(radioButton3);
            groupBox1.Controls.Add(radioButton2);
            groupBox1.Controls.Add(radioButton1);
            groupBox1.Location = new Point(49, 78);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(348, 281);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "A cărei țări aparține acest drapel ?";
            // 
            // button1
            // 
            button1.Location = new Point(121, 169);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 4;
            button1.Text = "Răspunde";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Location = new Point(22, 169);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(84, 24);
            radioButton4.TabIndex = 3;
            radioButton4.TabStop = true;
            radioButton4.Text = "Guineea";
            radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(22, 139);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(85, 24);
            radioButton3.TabIndex = 2;
            radioButton3.TabStop = true;
            radioButton3.Text = "Bulgaria";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(22, 109);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(75, 24);
            radioButton2.TabIndex = 1;
            radioButton2.TabStop = true;
            radioButton2.Text = "Spania";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(22, 79);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(63, 24);
            radioButton1.TabIndex = 0;
            radioButton1.TabStop = true;
            radioButton1.Text = "Italia";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Guineea;
            pictureBox1.Location = new Point(432, 157);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(209, 119);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // Form21
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox1);
            Controls.Add(menuStrip1);
            FormBorderStyle = FormBorderStyle.None;
            MainMenuStrip = menuStrip1;
            Name = "Form21";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form21";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem menuToolStripMenuItem;
        private ToolStripMenuItem laCâteÎntrebăriAmRăspunsPânăAcumToolStripMenuItem;
        private ToolStripMenuItem ceTrebuieSăFacToolStripMenuItem;
        private ToolStripMenuItem ieșireToolStripMenuItem;
        private GroupBox groupBox1;
        private Button button1;
        private RadioButton radioButton4;
        private RadioButton radioButton3;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private PictureBox pictureBox1;
    }
}